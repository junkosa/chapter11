class HomesController < ApplicationController
  def Top
  end
end
